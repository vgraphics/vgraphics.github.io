/* vgraphics.gr hosting check: a gzip file the browser unpacks */
